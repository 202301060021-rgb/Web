import path from 'node:path';
import { fileURLToPath } from 'node:url';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig } from 'vite';

const projectRoot = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  // GitHub Pages serves this project at /web/. Keep local builds path-relative.
  base: process.env.GITHUB_ACTIONS ? '/web/' : './',
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: { '@': path.resolve(projectRoot, 'src') },
    dedupe: ['react', 'react-dom'],
  },
  server: { host: '0.0.0.0' },
  preview: { host: '0.0.0.0' },
});
